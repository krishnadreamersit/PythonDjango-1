from django.apps import AppConfig


class App93Config(AppConfig):
    name = 'app9_3'
